from django.shortcuts import render
from django.http import HttpResponse
from studentapp.models import Student

def home(request):
    return HttpResponse("Welcome to our site!!!")

def about(request):
    return HttpResponse("This is about us page")
	
def students_list(request):
    students = Student.objects.all()
    return render(request, 'student_list.html', {
        'object_list': students
    })
# Create your views here.
