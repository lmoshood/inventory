from django.db import models


class Course(models.Model):
    course_title = models.CharField(max_length=70)
    course_code = models.CharField(max_length=70)
    department = models.CharField(max_length=70)
    def __str__(self):
        return self.course_title

class Student(models.Model):
    firstname = models.CharField(max_length=70)
    lastname = models.CharField(max_length=70)
    email = models.EmailField()
    course = models.ForeignKey(Course, default=0, on_delete=models.CASCADE)
    DOB = models.DateTimeField()
    

# Create your models here.
