from django.contrib import admin
from studentapp.models import Student
from studentapp.models import Course


admin.site.site_header = "Student Administration"
admin.site.site_title = "Student Management System "
admin.site.index_title = "Student Home"

class StudentAdmin(admin.ModelAdmin):
    list_display = ['firstname', 'lastname', 'email', 'course', 'DOB']


class CourseAdmin(admin.ModelAdmin):
    list_display = ['course_title', 'course_code', 'department']

admin.site.register(Student, StudentAdmin)
admin.site.register(Course, CourseAdmin)

# Register your models here.
